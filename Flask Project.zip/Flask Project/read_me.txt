Name of the application: 
Employee Management Application

Scope:
This application has a major scope for admin to carry out CRUD operations. However, employees can also log in and check their details but cannot amend any.

Technical prerequiste:
Flask
MySql

Admin Login Credentials:
Username-admin
Password-admin123

Flow:
In order to see employee details, you'll have to register your account and then log in.
From admin side, you can perform CRUD operations.


